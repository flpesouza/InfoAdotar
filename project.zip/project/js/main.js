$(document).ready(function () {
    menuToggleScript();
    closeTarget();
});

const menu = "#menu";
const menuToggle = "#menu-toggle";
const menuProfile = "#menu-profile";
const menuNav = "#menu-nav";
const notificationsSummary = "#notifications-summary";

//#region #menu-toggle

    function menuToggleScript() {
        $(menuToggle).click(function () {
            $(`${menu} > *:not(${menuToggle})`).toggle();
        });
    }

//#endregion

//#region Useful Components

    function closeTarget() {
        $(".close").click(function () {
            $(this).closest("." + this.getAttribute("data-target")).slideUp({"done": function() { $(this).remove() } });
        });
    }

//#endregion